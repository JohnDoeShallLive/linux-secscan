# secscan package initialization
